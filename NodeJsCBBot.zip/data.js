module.exports = {

mongoLink:'xxxx',// Database Link Of MongoDB

apikey:'xxxx',// Coinbase API Key

secretkey:'xxxxxx',// Coinbase 2nd Key

bot_token:'xxxx',// Bot Token

bot_name:'xxxx',// Bot Username Without @

bot_admin:1234567890,// Admin Telegram Id

channelsList : ['@TXTPayouts'],// Channels List

channelscheck : ['@Cha'],// Check Channels List

reffer_bonus:0.01,// Refferal Bonus Amount

min_wd:0.001,// Min Withdrawal Amount

daily_bonus:0.01,// Daily Bonus Amount

currency:'DOGE', // Bot Currency

payment_channel:'@Cha'// Payment Channel Username

}
