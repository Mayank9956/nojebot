For Using This NodeJs Bot You Need To Use API Of https://txt-dev.tk/cb
Don't Send Api Link To Anyone

How To Make Bot
1.) Go To Data.js { Change All Details }
2.) Then Go To https://github.com/
3.) If You Don't Have Account Then Register And Login Else Go To Repo.
4.) Make A New Repo. { Private , Add Readme }
5.) Now Delete Readme
6.) Upload All Files In Repo.
7.) Then Click On Code And Copy The Link
8.) Go To Settings
9.) Find Developer Settings
10.) Personal Access Token { If You Don't Have Then Make }
11.) Check All And Never Expire
12.) It You Have VPS Then Login Via { ssh root@YourIp }
13.) Now Install These 

i.) npm install pm2 -g
ii.) apt install git

14.) git clone 'repo link'
15.) any username ( tst )
16.) For password  Enter personal Access Token
17.) cd reponame
18.) npm i axios
19.) node index.js or pm2 start index.js --name "username tst"
20.) Done ✅✅